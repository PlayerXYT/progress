Progress is a simple library to create progress bars using the unicode box characters
